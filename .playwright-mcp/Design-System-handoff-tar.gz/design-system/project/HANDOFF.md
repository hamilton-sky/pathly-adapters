# Pathly — Design → Code Handoff

How to use the design mocks in this project and wire them to the Pathly backend.

> **What these files are:** self-contained HTML/CSS/JS mockups built on Pathly's real
> design tokens (`styles.css` + `tokens/`) and the actual brand/icon set. They are
> **presentation-fidelity prototypes with hardcoded demo data** — not wired to a server.
> To make them live you port the markup/styles into the real React components (which
> already own the data hooks) **or** replace the demo arrays with `fetch`/SSE/IPC calls.

---

## 1 · The files & what each maps to in the codebase

| Mock (this project) | Real component(s) in `studio/src/renderer/src/` | Purpose |
|---|---|---|
| `Skill Notebook.html` | `components/SkillNotebook/*`, `store/skillNotebookStore.ts`, `sidebar/panels/CatalogPanel` | Cell editor: body/fragment cells, catalog, live preview |
| `Canvas.html` | `components/FlowEditor/*` (`VisualView`, `StateNode`, `NodePanel`), `sidebar/panels/*` | Visual FSM flow editor + resource catalog |
| `Monitor.html` | `components/Monitor/*` (`index`, `FsmView`, `MetricsStrip`, `EventLog`, `StageCard`, `StageModal`) | Live FSM pipeline view + Configure-phase |
| `Flow Builder.html` | `components/FlowWizard/*` (`Step1Name`…`Step7TransitionRules`) | The flow-creation wizard, redesigned as one canvas |
| `appbar-brands.js` | `components/topbar/*` (`TopBar`, `EditorLauncher`, `TerminalLauncher`, `PanelNav`) | Global header split-buttons + brand-icon dropdowns |
| `styles.css` + `tokens/` | `styles/tokens.css`, `theme.ts` | Design tokens (colors, type, spacing) + 12 palettes |

Design explorations (not app screens): `Sidebar Directions.html`, `Palette Gallery.html`,
`slides/*`, `guidelines/*`, `components/*`, `ui_kits/*`.

---

## 2 · Foundations — reuse, don't re-pick

- **Tokens.** Everything reads CSS variables from `styles.css` (`--accent`, `--bg-*`,
  `--text-*`, `--state-*`, `--font-family-*`, `--radius-*`). These mirror
  `studio/.../styles/tokens.css`. Don't introduce new hex — map to a token.
- **Palettes.** 12 themes attach via `[data-theme="…"]` (Pathly Dark/Light, Nord, Mocha,
  Dracula, Rosé Pine, Solarized ±light, Latte, Paper, Dawn, Mint). Matches `theme.ts`.
- **Accent.** Sky `#38BDF8` is the one interactive accent. Pipeline-state colors
  (`--state-planning/building/reviewing/testing/done`) are the domain language — keep them.
- **Brand marks.** `appbar-brands.js` carries the real `VsCodeIcon` (`#007ACC`),
  `ShellIcon`, `ClaudeIcon`, `CodexIcon`, `AntigravityIcon`, plus File Explorer / Windows
  Terminal / Git Bash / WSL / PyCharm — lifted from `components/Terminal/BrandIcons.tsx`.

---

## 3 · Connecting the backend

Pathly's renderer talks to the host two ways; both already exist in the app:

- **`window.pathly` IPC bridge** (Electron): `fs.read/write/list/delete`,
  `shell.openVsCode/openInApp/openWindow`, `watch.watchWorkspace/onWorkspaceChanged`.
- **FSM server HTTP/SSE** (`fsm-server-sqlite`, ~`http://localhost:8765`): e.g.
  `/skills/catalog`, `/skills/parse`, the SSE event stream, and the plan DB `pathly.db`.

`monitorSource` is already `'sse' | 'file-watch'` in the store — the live/SSE badge in the
Monitor mock reflects that.

### 3.1 Monitor — `Monitor.html`
**Read (live pipeline).** Subscribe to the FSM event stream and render from state:
- Source: SSE from the FSM server, or `watch.onWorkspaceChanged` on the plan dir / `pathly.db`.
- On each event → append an `.erow` to the event log, advance the stepper
  (`.step.done/.active/.todo` + `.step-line.on`), and recompute the 4 metric cards
  (tokens / wall / cost / events). Replace the static arrays with a `render(state)` fed by
  the stream (this is what `Monitor/index.tsx` + `runnerStore` already do).
- Event shape (from `StageLogEntry` / runner): `{ stage, adapter, agent, exitCode,
  durationMs, costUsd, inputTokens, outputTokens, result, prompt, … }`.

**Write (Configure phase modal).** "Apply" persists the chosen **host / agent / skill** for
that stage into the flow config:
- Write the stage's `adapter_map` + agent + skill to the flow YAML via
  `window.pathly.fs.write(flowPath, yaml)` (see `FlowWizard/utils.ts → generateYaml`), or
  POST to the FSM server.
- Hosts = `claude | codex | copilot | agy(antigravity)` (see `lib/adapters.gen.ts`,
  `ConfigForm` ADAPTER_OPTIONS). "Open skill in Notebook" → set
  `activePanel='skill-notebook'` + `skillNotebookPath`.

### 3.2 Skill Notebook — `Skill Notebook.html`
- **Load:** `loadSkill(path)` → `POST {server}/skills/parse {skill_path}` → `body_cells` +
  `fragment_cells` (see `store/skillNotebookStore.ts`).
- **Catalog:** `GET {server}/skills/catalog` → fragments (the sidebar list).
- **Edit ops:** `insertFragment / moveCell / removeCell / undo / redo` already exist in the
  store (50-step history). Body cells are immutable; fragments reorder/remove.
- **Live preview:** recompose on cell change → the "Composed skill" panel + token count.
- **Save → DB:** the Save toast = write composed skill + persist to `pathly.db`.

### 3.3 Canvas — `Canvas.html`
- **Catalog (Flows/Agents/Skills/Templates + custom categories):** read project dirs via
  `fs.list` (see `hooks/useProjectFiles.ts`, `WORKSPACE_*_SECTIONS`,
  `customWorkspaceSections`). Custom categories = user-created folders.
- **Node inspector:** per-state `agent / adapter(host) / skill / gate / transitions`;
  writes to the flow YAML (`FlowEditor` + `flowToGraph` / `exportPaths`).
- **Drag onto canvas:** the `PATHLY_DRAG_MIME` payload (`dragType:'canvas'`) already used by
  the sidebar → canvas drop in `VisualView/hooks/useCanvasDnD.ts`.

### 3.4 Flow Builder / transition rules — `Flow Builder.html`
- Per-state config = wizard Steps 2–7 collapsed into one inspector. Data model in
  `FlowWizard/types.ts`: `Transition{from,to,label}`, `Gate`, `ArtifactCondition`,
  `TransitionRule{conditions[],default}`, `FeedbackRoute{tag,agent}`, `adapterMap`.
- "Routing" rule = `TransitionRule` (artifact → target) + `FeedbackRoute` (tag → agent).
- Output via `generateYaml(...)`; save with `fs.write` to `{userHome}/flows/{name}.flow.yaml`.

### 3.5 Header — `appbar-brands.js`
- VS Code split → `shell.openVsCode(projectPath)` + dropdown `shell.openInApp(path, kind)`
  (`vscode|explorer|terminal|gitbash|wsl|pycharm`) — see `EditorLauncher.tsx`.
- Terminal split → `launchMiniTerminal(kind)` (`shell|claude|codex|antigravity`) — see
  `TerminalLauncher` / `lib/terminalOptions.tsx`.
- Nav tabs (Canvas/Notebook/Monitor) → `setActivePanel(...)` (`PanelNav.tsx`).
- New window → `shell.openWindow(projectPath)`. Publish → `PublishControl`.

---

## 4 · Porting a mock into a component (recommended path)

1. Open the mock + its target component side by side.
2. Copy the **markup structure + classNames** into the component's JSX (or a CSS module);
   the class names already use the token variables, so styling carries over.
3. Delete the demo arrays; bind to the store / props the component already receives.
4. Wire the actions (onClick, Apply, drag) to the existing store actions / IPC above.
5. Keep `data-testid`s where the originals had them so existing tests pass.

> Fastest route if you don't want to port by hand: drop the mock's `<style>` into a CSS
> module and the markup into the component, then replace `.map` over demo data with the
> real selector. The visual result is 1:1 because both use `tokens.css`.

---

## 5 · Caveats

- Mocks load React/Babel from a CDN for the Tweaks panel only; the app uses its bundled
  React — don't copy the CDN tags.
- `appbar-brands.js` injects its own `<style>` + fills `[data-brand]`; in the app, use the
  real `BrandIcons.tsx` components instead.
- Demo numbers (tokens/cost/timestamps) are illustrative — they come from the runner in
  the real app.
